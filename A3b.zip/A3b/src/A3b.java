/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2016-10-15
* Created for: ICS4U
* Assignment: 3b
* Binary search
*
*******************************************************************************/


import java.util.Random;
import java.util.Scanner;

public class A3b {

	public static boolean binarySearch(int userImput, int array[]){
		int low=0;
		int high=(array.length - 1);
		while (low<=high){
			int middle = (low+high)/2;
			if (array[middle]==userImput){
				return true;
			}
			else if (array[middle]<userImput){
				low = middle +1;
			}
			else if (array[middle]>userImput){
				high = middle-1;
			}
		}
		if (low<=high){return true;}
		else return false;
	}
	
	
    public static void bubbleSort(int[] array)
    {
        for(int counter=0; counter<array.length; counter++)
        {
            for(int flag=counter + 1; flag<array.length; flag++)
            {
                if(array[counter] > array[flag])
                {
                    int temp = array[counter];
                    array[counter] = array[flag];
                    array[flag] = temp;
                }
            }
        }
    }
	
	public static void main(String[] args) {
		 	
			Random rand = new Random();
	        int[] array = new int[250];
	        System.out.print("Unsorted:\n");
	        
	        for(int i = 0; i <  array.length; i++) {      	
	        	int randomNumber = rand.nextInt(1000) + 1; //random # from 0-1000
	            array[i] = randomNumber;
	            System.out.print(array[i]+ "\n");
	        }
	        
	        bubbleSort(array);
	        System.out.print("Sorted:\n");
	        
	        for(int i = 0; i <  array.length; i++) {
	            System.out.print(array[i]+ "\n");
	        }	  
	        
	        Scanner SCAN = new Scanner(System.in);
	        System.out.print("Number to check in array: ");
	        int numberToCheck = SCAN.nextInt();
	        
	        //call boolean function
	        boolean yesorno = binarySearch(numberToCheck, array);
	        if (yesorno==true){
	        	System.out.print("Number is in array!");
	        }
	        else if (yesorno==false){
	        	System.out.print("Number is not in array!");
	        }
	        else {System.out.print("-1");}
	}

}
